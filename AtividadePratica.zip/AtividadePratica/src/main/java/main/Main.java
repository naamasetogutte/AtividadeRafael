package main;

import repository.UserRepository;
import entities.User;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Conectar ao banco de dados SQLite
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");

            // Executar o script init.sql para criar a tabela 'users'
            runScript(connection, "scripts/init.sql");

            // Inicializar o repositório de usuários
            UserRepository userRepository = new UserRepository(connection);

            // Menu de opções
            while (true) {
                System.out.println("1. Cadastrar usuário");
                System.out.println("2. Listar usuários");
                System.out.println("3. Sair");

                int option = scanner.nextInt();
                scanner.nextLine(); // Limpar o buffer do scanner

                switch (option) {
                    case 1:
                        // Cadastrar usuário
                        System.out.print("Nome: ");
                        String name = scanner.nextLine();

                        System.out.print("Email: ");
                        String email = scanner.nextLine();

                        System.out.print("Senha: ");
                        String password = scanner.nextLine();

                        // Criar um novo objeto User
                        User user = new User(name, email, password);

                        // Salvar o usuário no banco de dados
                        userRepository.save(user);

                        System.out.println("Usuário cadastrado com sucesso!");
                        break;

                    case 2:
                        // Listar todos os usuários
                        userRepository.findAll().forEach(u -> {
                            System.out.println("ID: " + u.getUuid() + " | Nome: " + u.getName() + " | Email: " + u.getEmail());
                        });
                        break;

                    case 3:
                        // Sair
                        System.out.println("Saindo...");
                        return;

                    default:
                        System.out.println("Opção inválida.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Função para executar o script init.sql
    private static void runScript(Connection connection, String scriptPath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(new File(scriptPath)))) {
            StringBuilder script = new StringBuilder();
            String line;

            // Lê o conteúdo do arquivo linha por linha
            while ((line = reader.readLine()) != null) {
                script.append(line).append("\n");  // Adiciona cada linha ao conteúdo do script
            }

            // Executa o script como uma string
            Statement statement = connection.createStatement();
            statement.execute("PRAGMA foreign_keys=ON;");  // Habilita as chaves estrangeiras (se necessário)
            statement.executeUpdate("BEGIN TRANSACTION;");
            statement.execute(script.toString());  // Executa o script lido
            statement.executeUpdate("COMMIT;");
            System.out.println("Script SQL executado com sucesso.");

        } catch (IOException e) {
            System.out.println("Erro ao ler o script SQL: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("Erro ao executar o script SQL: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
