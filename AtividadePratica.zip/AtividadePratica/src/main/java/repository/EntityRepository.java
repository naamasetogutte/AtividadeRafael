package repository;

import entities.User;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface EntityRepository<T> {
    void save(T entity);
    Optional<T> findById(UUID uuid);
    List<User> findAll();
    void deleteById(UUID uuid);
}
